


{
         echo '================need protective, start use DX protective technology for channel apk================'
         #使用顶象加固64位包
         #!/bin/bash -ilex
         cd "/Users/jion/.jenkins/workspace/multi_channel_private"
         outPutPath="/Users/jion/workspace/gktapp-release/android-store"
         inPutApk=${WORKSPACE}/android/app/build/outputs/apk/prd64/release/app-prd64-release.apk
         outPutApk=${outPutPath}/unsigned/store_gtkapp_prd64.apk
         dXTool="/Users/jion/.jenkins/workspace/multi_channel_private"

         # 加固
         mkdir -p ${outPutPath}/unsigned
         python ${dXTool}/appensys_cli.py \
            --host-url=http://appen.dingxiang-inc.com \
            --account=18721756393 --password=Ld1234567 \
            --package-type=android_app \
            --strategy-id=0 \
            -i ${inPutApk} \
            -o ${outPutApk}

         #签名 + 多渠道
         java -jar -Dfile.encoding=utf-8 ${dXTool}/dx-signer.jar sign \
            --ks ${dXTool}/greenland.jks \
            --ks-key-alias green-land-financial \
            --ks-pass greenland-financial \
            --key-pass greenland-financial \
            --channel-list ${dXTool}/channel.txt \
            --in ${outPutApk} \
            --out ${outPutPath}

}
