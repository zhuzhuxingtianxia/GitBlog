#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""

Usage: appensys_cli.py [options]

顶象加固系统命令行，支持SAAS、私有化盒子

Options:
  --version             show program's version number and exit
  -h, --help            show this help message and exit
  -i INPUT, --input=INPUT
                        加固前文件（输入） *.apk/zip/aar/xcarchive
  -o OUTPUT, --output=OUTPUT
                        加固后文件保存位置（输出）
  --host-url=HOST_URL   加固的服务端
  --dx-saas             等价于 --host-url=http://appen.dingxiang-inc.com
  -s STRATEGY_ID, --strategy-id=STRATEGY_ID
                        策略编号
  -t PACKAGE_TYPE, --package-type=PACKAGE_TYPE
                        文件类型：android_app, android_sdk, ios_app, ios_sdk,
                        binary, android_scan, ios_scan, h5_sdk
  -a ACCOUNT, --account=ACCOUNT
                        账户
  -p PASSWORD, --password=PASSWORD
                        密码
  --class-list-json=CLASS_LIST_JSON
                        [android_sdk] 保护的类名列表，json格式
  --entry-class=ENTRY_CLASS
                        [android_sdk] 入口类名
  -b, --keep-bitcode-in-output
                        [ios_app, ios_sdk] 加固后是否开启bitcode, 默认不保留
  --xcode=XCODE         [ios_app, ios_sdk] 打包使用的Xcode版本
                           10: Xcode 13.3-13.4
                            9: Xcode 13.0-13.2
                            8: Xcode 12.5
                            7: Xcode 12.0-12.4
                            6: Xcode 11.4
                            5: Xcode 11.0-11.3
                            4: Xcode 10.2-10.3
                            3: Xcode 10.0-10.1
                            2: Xcode 9.x 废弃
                            1: Xcode 9.x 废弃
  --saas-accounting-by-package
                        [saas] SAAS按包计费方式, 否则按次数计费方式

1. 例如使用saas服务加固一个Android的APP
appensys_cli.py --package-type=android_app --dx-saas --account=bob --password=bob --strategy-id=1000 -i in.apk -o protected.apk

2. 例如使用saas服务加固一个ios的APP
appensys_cli.py --package-type=ios_app --host-url=http://appen.dingxiang-inc.com --account=bob --password=bob --strategy-id=1000 -i in.zip -o protected.zip --xcode=6

3. 例如使用saas服务加固一个ios的APP，相对于例2, 额外在输出的文件中保留bitcode
appensys_cli.py --package-type=ios_app --host-url=http://appen.dingxiang-inc.com --account=bob --password=bob --strategy-id=1000 -i in.zip -o protected.zip --xcode=6 --keep-bitcode-in-output

4. 例如使用[多租户下]服务加固一个ios的APP
appensys_cli.py --package-type=ios_app --host-url=http://10.0.1.2:8080/api/index --account=bob --password=bob --strategy-id=1000 -i in.zip -o protected.zip --xcode=6 --keep-bitcode-in-output
uri 中 index 为企业对应的code, 可在系统配置-> 系统更新 -> 授权信息进行查看


"""
import base64, hashlib
from io import BytesIO
import requests
import time
import os
import codecs
import traceback
from optparse import OptionParser

def calc_md5_bytes(local_path):
    DEFAULT_CHUNK_SIZE = 1024 * 1024  # 计算MD5值时,文件单次读取的块大小为1MB
    m = hashlib.md5()
    with open(local_path, 'rb') as fp:
        chunk = fp.read(DEFAULT_CHUNK_SIZE)
        while chunk:
            m.update(chunk)
            chunk = fp.read(DEFAULT_CHUNK_SIZE)
    return m.digest()

class AppGuardAPI:
    dgc_host_url = ""
    account = ""
    password = ""
    # 单位秒
    timeout = 100
    token = ""

    def __init__(self, _url, _account, _passowrd, _corp):
        self.dgc_host_url = _url
        self.account = _account
        self.password = _passowrd
        self.corp = _corp
        self.__get_token()

    def __get_token(self):
        if self.corp is not None and len(self.corp) > 0:
            url = "{}/v3/authorize?userName={}&userPassword={}&corp={}".format(
            self.dgc_host_url, self.account, self.password, self.corp)
        else:
            url = "{}/v1/authorize?userName={}&userPassword={}".format(
                self.dgc_host_url, self.account, self.password)
        try:
            response_json = self.__get_response(url, False).json()
        except Exception as inst:
            traceback.print_exc()
            return ""

        if len(response_json) == 0 or ("status" in response_json and response_json["status"] != 200):
           raise Exception("[!] fail to auth for token: response null or network err")

        if response_json["success"] is True:
            self.token = response_json["data"]
            # print("Token: {}".format(self.token))
            return self.token
        else:
            print ("[!] fail to auth for token: '%s'"%(response_json,))
            if response_json["code"] == '-9003':
                print("-------------")
                print("CORP_NOT_EXIST:: please set corp [CODE] by command line:")
                print()
                print("    --host-url={}/api/[CODE]".format(self.dgc_host_url))
                print()
                print("    [CODE] can be found {}/static/index.html#/setting after login".format(self.dgc_host_url))
                print("-------------")
            raise Exception("fail to auth for token")

    # 新建任务
    # return 0 if fail
    def __new_task(self, strategyId, file_path, params, retry=3):
        new_task_parameters = {}
        new_task_parameters["token"] = self.token
        task_name=os.path.basename(file_path)
        new_task_parameters["strategyInfoId"] = str(strategyId)
        new_task_parameters["name"] = task_name
        if ("packageType" in params):
            new_task_parameters["packageType"] = params["packageType"]
        if ("authType" in params):
            new_task_parameters["authType"] = params["authType"]
        #
        if ("entryClass" in params):
            new_task_parameters["entryClass"] = params["entryClass"]
        #
        if ("content" in params):
            new_task_parameters["content"] = params["content"]
        #
        if ("isBitCode" in params):
            new_task_parameters["isBitCode"] = params["isBitCode"]
        #
        if ("xcodeVersion" in params):
            new_task_parameters["xcodeVersion"] = params["xcodeVersion"]
        #
        #print (new_task_parameters)

        url = "{}/v1/task".format(self.dgc_host_url)
        # print url
        maxRetry = retry
        tryNow = 0
        
        while True:
            try:
                print ("[+] posting file with task-name '%s'"%(task_name,))
                md5 = calc_md5_bytes(file_path)
                print("[+] input file md5 %s" % (md5.hex(),))
                md5_base64 = base64.standard_b64encode(md5).decode('utf-8')
                new_task_parameters['fileMd5Base64'] = md5_base64
                with open(file_path, 'rb') as f:
                    r = requests.post(url=url, data=new_task_parameters, files={'file': f})
                    if r.text == "":
                        print ("[!] server response fail [%s]"%r.text)
                        return -2
                    #
                    response = r.json()
                #

                if response["success"]:
                    return response["data"]
                else:
                    if (tryNow >= maxRetry):
                        print ("[!] too much try, failing with [0]")
                        return 0
                    #
                    print ("[+] server response unexpected, try again: %r"%response)
                    tryNow += 1
                #
            #
            except requests.exceptions.ConnectionError as e:
                if (tryNow >= maxRetry):
                    raise
                    return -1
                #
                tryNow += 1
            #
        #
        
    #

    # 取得任务状态, 1:正在加固；0:加固完成；-1:加固失败
    def __get_task_status(self, task_id):
        if self.token_is_empty() is True:
            return -1
        url = "{}/v1/task/{}?token={}".format(self.dgc_host_url, task_id, self.token)

        cur_status = 0
        try:
            cur_status = self.__get_response(url, show_json_data=False).json()
        except Exception as inst:
            traceback.print_exc()
            return -1

        #
        # print cur_status
        if ("data" not in cur_status):
            print ("data not in resp server return %s"%cur_status)
            return "-1"
        #
        data_info = cur_status["data"]

        status = data_info["status"]
        
        return str(status)
    #

    # 取得保护后文件
    def __get_task_file(self, task_id, download_file_path):
        if self.token_is_empty() is True:
            return
        url = "{}/v1/task/file/{}?token={}&type={}&mode={}".format(self.dgc_host_url,
                                                                   task_id,
                                                                   self.token,
                                                                   "1",
                                                                   "1")
        try:
            response = self.__get_response(url, show_json_data=False)
        except Exception as inst:
            traceback.print_exc()
            return False

        rep_content = response.content
        if len(rep_content) < 200 and rep_content.find("success\":false"):
            print (rep_content)
            return False
        
        with open(download_file_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=1024):  # 邊下载邊儲存
                if chunk:
                    f.write(chunk)
                #
            #
            time.sleep(1)
        if 'Content-MD5' in response.headers:
            content_md5_base64 = response.headers['Content-MD5']
            md5 = base64.standard_b64decode(content_md5_base64)
            print("[+] expected md5: %s " % (md5.hex(),))

            actual_md5 = calc_md5_bytes(download_file_path)
            print("[+] actual md5: %s " % (actual_md5.hex(),))
            if actual_md5 != md5:
                print("[+] fail to download file content different")
                return False
        #
        return True

    def __get_response(self, url, show_json_data, retry=3):
        maxRetry = retry
        tryNow = 0
        timeout = self.timeout
        while True:
            try:
                # print("HTTP Requests URL: {}".format(url))
                response = requests.get(url=url, timeout=timeout, stream=True)
                if show_json_data:
                    print("HTTP Response JSON Data: {}".format(response.json()))
                return response
            except requests.exceptions.RequestException as e:
                if (tryNow>=maxRetry):
                    print ("exception after %d retry"%maxRetry)
                    raise
                    return
                #
                tryNow += 1
            #
        #
    #


    def token_is_empty(self):
        if self.token == "":
            print("token error")
            return True
        else:
            return False

    def doAppEnc(self, orig_path, out_path, strategyId, params={}):
        print("[+] creating task for '%s'" % (orig_path,))
        taskId = self.__new_task(strategyId, orig_path, params)
        if taskId <= 0:
            print("[-]upload %s fail, return invalid task id %d"%(orig_path, taskId))
            return False
        #
        print("[+] task created: %d "%(taskId,))

        retry_times = 0
        prev_status = '-1'
        code2log = {"0":"waiting", "1":"protecting", "2":"finished"}
        while True:
            cur_status = str(self.__get_task_status(taskId))
            if (cur_status in code2log):
                if (cur_status != prev_status):
                    prev_status = cur_status
                    log = code2log[cur_status]
                    print ("[+] task %s => %s..."%(taskId, log))
                    if (cur_status == '2'):
                        break
                    #
            else:
                if retry_times == 20:
                    print ("[-] protect "+orig_path+" fail, exit")
                    return False
                else:
                    print ("[-] protect %s return %s retry"%(orig_path, cur_status))
                retry_times = retry_times + 1
            #
            time.sleep(3)
            #

        print("[+] downloading output for task ...")
        if not self.__get_task_file(taskId, out_path):
            print ("[-] download "+out_path+" fail, exit")
            return False

        print("[+] downloaded to %s" % (out_path,))
        return True


# 这个入口用于测试api接口使用
# 需要request库,安装
# pip install requests -i https://pypi.tuna.tsinghua.edu.cn/simple
import sys
if __name__ == "__main__":

    description="顶象加固系统命令行，支持SAAS、私有化盒子"
    parser = OptionParser(usage="usage: %prog [options]", version='V20200415', description=description)
    parser.add_option("-i", "--input",          dest="input",  help="加固前文件（输入） *.apk/zip/aar/xcarchive")
    parser.add_option("-o", "--output",         dest="output", help="加固后文件保存位置（输出）")
    parser.add_option("--host-url",       dest="host_url", help="加固的服务端")
    parser.add_option("--dx-saas",        action="store_true", dest="dx_saas", help="等价于 --host-url=http://appen.dingxiang-inc.com", default=False)
    parser.add_option("-s", "--strategy-id",    dest="strategy_id", help="策略编号")
    parser.add_option("-t", "--package-type",    dest="package_type", help="文件类型：android_app, android_sdk, ios_app, ios_sdk, binary, android_scan, ios_scan, h5_sdk")
    parser.add_option("-a", "--account",    dest="account", help="账户")
    parser.add_option("-p", "--password",    dest="password", help="密码,如果密码中含有$等特殊字符，请用''单引号转义")
    parser.add_option("--class-list-json",   dest="class_list_json", help="[android_sdk] 保护的类名列表，json格式")
    parser.add_option("--entry-class",      dest="entry_class", help="[android_sdk] 入口类名")
    parser.add_option("-b", "--keep-bitcode-in-output",    action="store_true",  dest="is_bitcode", help="[ios_app, ios_sdk] 加固后是否开启bitcode, 默认不保留", default=False)
    parser.add_option("--xcode",      dest="xcode", help="[ios_app, ios_sdk] 打包使用的Xcode版本，10: Xcode13.3-13.4, 9: Xcode 13.0-13.2, 8: Xcode 12.5, 7: Xcode 12.0-12.4, 6: Xcode 11.4, 5: Xcode 11.0-11.3, 4: Xcode 10.2-10.3, 3: Xcode 10.0-10.1")
    parser.add_option("--saas-accounting-by-package", action="store_true", dest="saas_accounting_by_package", help="[saas] SAAS按包计费方式, 否则按次数计费方式", default=False)
    parser.add_option("--corp",    dest="corp", help="企业")

    try:
        (options, args) = parser.parse_args()
    except UnicodeDecodeError:
        (pyVersion, _, _, _, _) = sys.version_info
        if pyVersion <= 2:
            print("py2 上无法打印 -h/--help, 请打开这个py文件，在文件头上有使用说明")
            sys.exit(-1)

    try:
        if options.help:
            parser.print_help()
    except AttributeError:
        pass

    if options.dx_saas:
        options.host_url='http://appen.dingxiang-inc.com'

    if options.host_url is None or options.input is None or options.output is None or options.account is None or options.password is None or options.package_type is None or options.strategy_id is None:
        print("ERROR: --host-url/--input/--output/--account/--password/--package-type/--strategy-id是必须的")
        sys.exit(-1)

    if options.package_type == 'ios_app' or options.package_type == 'ios_sdk':
        if options.xcode is None:
            print("ERROR: [ios_app/ios_app] --xcode必须指定， 您可以试试--xcode=6")
            sys.exit(-1)
    if options.package_type == 'android_sdk':
        if options.class_list_json is None:
            print("ERROR: [android_sdk] --class-list-json必须指定")
            sys.exit(-1)
        if options.entry_class is None:
            print("ERROR: [android_sdk] --entry-class必须指定")
            sys.exit(-1)

    strategyId = sys.argv[4]


    params = {}

    # FIXME legacy support, we will simplify the code to following in next release
    params["packageType"] = options.package_type

    if options.host_url.find('appen.dingxiang-inc.com') > 0:
        # saas
        if options.package_type == "android_app" or options.package_type == "ios_app":
            params["packageType"] = options.package_type[0: -4] # android or ios
        else:
            print("ERROR: SAAS版本不支持--package-type=" + options.package_type)
            sys.exit(-1)
        if options.saas_accounting_by_package:
            params["authType"] = "2"
        else:
            params["authType"] = "1"
        #


    appGuard_object = AppGuardAPI(options.host_url, options.account, options.password, options.corp)
    if (options.package_type == "android_sdk"):
        with codecs.open(options.class_list_json, 'r', encoding="utf-8") as f:
            params["content"] = f.read()
        #
        params["entryClass"] = options.entry_class
    #
    elif (options.package_type == "ios_app" or options.package_type == "ios_sdk"):
        if options.is_bitcode:
            params["isBitCode"] = '1'
        else:
            params["isBitCode"] = '0'
        params["xcodeVersion"] = options.xcode
    #

    in_file = options.input
    out_file = options.output

    r = appGuard_object.doAppEnc(in_file, out_file, options.strategy_id, params)
    if (not r):
        print ("FAILED")
        sys.exit(1)
    else:
        print ("SUCCESS")
        sys.exit(0)
    #

#
